import os
import glob
import mutagen
import requests
import urllib
from bs4 import BeautifulSoup

# LYC 형식 : [mm:ss.xx]가사
FILE_LIST = []
TAG_LIST = []
TIME = []
LYRICS = []
mm = []
ss = []
xx = []
a1=[]
a2=[]
a3=[]

for file in glob.glob("*.flac"):    # flac파일 개수 파악
    FILE_LIST.append(file)
if FILE_LIST != []:  # flac파일이 있는 경우
    for i in range(0, len(FILE_LIST)):
        FILE_TAG_LIST = mutagen.File("%s" % FILE_LIST[i])  # 한 곡의 모든태그들은 딕셔너리형태로 저장됨
        TAG_LIST.append(FILE_TAG_LIST)  # 두개 이상의 곡 일때, 각각 FILE_TAG_LIST를 리스트 형식으로 저장
    for i in range(0, len(FILE_LIST)):
        if TAG_LIST[i]['artist'] != '' and TAG_LIST[i]['album'] != '' and TAG_LIST[i]['title'] != '':  # 곡에 태그 3가지 모두 있을 때
            req_integrated = requests.get('https://music.bugs.co.kr/search/integrated?q=%s %s' % (TAG_LIST[i]['title'], TAG_LIST[i]['artist']))
            req_album = requests.get('https://music.bugs.co.kr/search/album?q=%s %s' % (TAG_LIST[i]['album'], TAG_LIST[i]['artist']))
            req_artist = requests.get('https://music.bugs.co.kr/search/artist?q=%s' % TAG_LIST[i]['artist'])
            html_integrated = req_integrated.text
            soup_integrated = BeautifulSoup(html_integrated, 'html.parser')
            html_album = req_album.text
            soup_album = BeautifulSoup(html_album, 'html.parser')
            html_artist = req_artist.text
            soup_artist = BeautifulSoup(html_artist, 'html.parser')
            for id in soup_integrated.find_all("tr"):
                if id.get("artistid"):
                    a1.append(id.get("artistid"))
                if id.get("albumid"):
                    a2.append(id.get("albumid"))
                if id.get("trackid"):
                    a3.append(id.get("trackid"))
            for id in soup_album.select('#container > section > div > ul > li:nth-of-type(1) > figure'):  # 앨범검색 결과
                b1 = id['artistid']
                b2 = id['albumid']
            for id in soup_artist.select('#container > section > div > ul > li:nth-of-type(1) > figure > figcaption > a.artistTitle'):  # 아티스트 결과
                c1=id['href'][32:-25]
            for y in range(0,len(a1)):
                if a1[y] == b1 == c1 and a2[y] == b2:
                    urllib.request.urlretrieve('http://api.bugs.co.kr/3/tracks/%s/lyrics' % a3[y],"%s.lrc" % FILE_LIST[i].replace(".flac", ""))
                    with open("%s.lrc" % FILE_LIST[i].replace(".flac", ""), 'r', encoding='UTF8') as file:
                        line = file.read()
                    if os.path.getsize("%s.lrc" % FILE_LIST[i].replace(".flac", "")) < 200:  # 200바이트 이하는 싱크가사가 없음
                        print("======================================")
                        print("%s번째 시도 '%s' 곡은 싱크가사가 없습니다." %(y+1,FILE_LIST[i]))
                        print("======================================")
                        os.remove("%s.lrc" % FILE_LIST[i].replace(".flac", ""))
                        continue
                    else:  # 200바이트 이상은 싱크가사가 있음
                        if "|" in line :
                            line = line[line.find('"lyrics":"'):line.rfind('","type"')].replace("＃", "\n").replace('"lyrics":"', "")
                            with open("%s.lrc" % FILE_LIST[i].replace(".flac", ""), 'w', encoding='UTF8') as file:
                                file.write(line)
                            with open("%s.lrc" % FILE_LIST[i].replace(".flac", ""), 'r', encoding='UTF8') as file:
                                TEXT = []
                                for x in range(0, line.count("\n") + 1):
                                    TEXT.append(file.readline())
                            for x in range(0, line.count("\n") + 1):
                                TIME.append(TEXT[x][:TEXT[x].rfind("|")])
                                LYRICS.append(TEXT[x][TEXT[x].rfind("|") + 1:])
                            with open("%s.lrc" % FILE_LIST[i].replace(".flac", ""), 'w', encoding='UTF8') as file:
                                file.write('')
                            for x in range(0, line.count("\n") + 1):
                                if "." in TIME[x]:  # xx가 있을 경우
                                    if TIME[x][:TIME[x].rfind(".")] != '':
                                        if int(TIME[x][:TIME[x].rfind(".")]) // 60 < 10:  # mm 추출
                                            mm.append("0" + str(int(TIME[x][:TIME[x].rfind(".")]) // 60))
                                        else:
                                            mm.append(str(int(TIME[x][:TIME[x].rfind(".")]) // 60))
                                        if int(TIME[x][:TIME[x].rfind(".")]) % 60 < 10:  # ss 추출
                                            ss.append("0" + str(int(TIME[x][:TIME[x].rfind(".")]) % 60))
                                        else:
                                            ss.append(str(int(TIME[x][:TIME[x].rfind(".")]) % 60))
                                        if len(TIME[x][TIME[x].rfind(".") + 1:]) == 1:  # xx 추출
                                            xx.append(TIME[x][TIME[x].rfind(".") + 1:] + "0")
                                        else:
                                            xx.append(TIME[x][TIME[x].rfind(".") + 1:])
                                    with open("%s.lrc" % FILE_LIST[i].replace(".flac", ""), 'a',encoding='UTF8') as file:
                                        if TIME[x][:TIME[x].rfind(".")] != '':
                                            file.write("[" + mm[x] + ":" + ss[x] + "." + xx[x] + "]" + LYRICS[x])
                                else:
                                    if TIME[x][:TIME[x].rfind(".")] != '':
                                        if int(TIME[x]) // 60 < 10:
                                            mm.append("0" + str(int(TIME[x]) // 60))
                                        else:
                                            mm.append(str(int(TIME[x]) // 60))
                                        if int(TIME[x]) % 60 < 10:
                                            ss.append("0" + str(int(TIME[x]) % 60))
                                        else:
                                            ss.append(str(int(TIME[x]) % 60))
                                        with open("%s.lrc" % FILE_LIST[i].replace(".flac", ""), 'a',encoding='UTF8') as file:
                                            if TIME[x][:TIME[x].rfind(".")] != '':
                                                file.write("[" + mm[x] + ":" + ss[x] + "." + "00" + "]" + LYRICS[x])
                            TIME.clear()
                            mm.clear()
                            ss.clear()
                            xx.clear()
                            a1.clear()
                            a2.clear()
                            a3.clear()
                            LYRICS.clear()
                            print("%s. " % i + "'%s.lrc'" % FILE_LIST[i].replace(".flac", "") + "가 저장되었습니다.")
                            if glob.glob("%s.lrc" % FILE_LIST[i].replace(".flac", "")):
                                if i == len(FILE_LIST) - 1:
                                    print("LRC파일 추출을 완료하였습니다.")
                                    break
                            break
                        else:
                            print("======================================")
                            print("안타깝게도 '%s' 곡은 싱크가사가 없습니다." % FILE_LIST[i])
                            print("======================================")
                            os.remove("%s.lrc" % FILE_LIST[i].replace(".flac", ""))
                            break

                else:
                    if y == len(a1)-1:
                        a1.clear()
                        a2.clear()
                        a3.clear()
                        print("============================================================")
                        print("%s곡의 통합검색 및 앨범 검색결과 각각의 아티스트 ID와 앨범 ID가 다릅니다." % FILE_LIST[i])
                        print("============================================================")

        else:  # 곡에 태그 3가지중 하나라도 없을 때
            print("===========================================")
            print("%s곡의 태그가 없습니다." % FILE_LIST[i])
            print("===========================================")

else: # flac파일이 없는 경우
    print("========================================")
    print("파일이 없습니다. 확인 후 다시 실행해 주세요.")
    print("========================================")
